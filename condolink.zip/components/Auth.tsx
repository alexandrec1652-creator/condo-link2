
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { dbService } from '../services/dbService';

interface AuthProps {
  mode: 'STAFF' | 'RESIDENT';
  onBack: () => void;
  onSuccess: (user: User) => void;
}

const STAFF_FIXED_CREDENTIALS: User = {
  id: 'staff-default',
  name: 'Portaria Edifício Jaú',
  email: 'edificio-jau-1528',
  password: 'jau1528',
  role: 'STAFF'
};

const Auth: React.FC<AuthProps> = ({ mode, onBack, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [rememberMe, setRememberMe] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    unit: '',
    phone: ''
  });

  useEffect(() => {
    const saved = localStorage.getItem(`condolink_remember_${mode}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setFormData(prev => ({
          ...prev,
          email: parsed.email || '',
          unit: parsed.unit || '',
          password: parsed.password || ''
        }));
        setRememberMe(true);
      } catch (e) {
        console.error("Erro ao carregar dados salvos");
      }
    }
    if (mode === 'STAFF') setIsLogin(true);
  }, [mode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const state = dbService.getState();
    let authenticatedUser: User | undefined;

    if (isLogin) {
      if (mode === 'STAFF') {
        if (formData.email === STAFF_FIXED_CREDENTIALS.email && formData.password === STAFF_FIXED_CREDENTIALS.password) {
          authenticatedUser = STAFF_FIXED_CREDENTIALS;
        }
      } else {
        authenticatedUser = state.users.find(u => 
          u.role === 'RESIDENT' && u.unit === formData.unit && u.password === formData.password
        );
      }

      if (authenticatedUser) {
        if (rememberMe) {
          localStorage.setItem(`condolink_remember_${mode}`, JSON.stringify({
            email: formData.email,
            unit: formData.unit,
            password: formData.password
          }));
        } else {
          localStorage.removeItem(`condolink_remember_${mode}`);
        }
        onSuccess(authenticatedUser);
      } else {
        alert(mode === 'STAFF' ? 'Credenciais de portaria inválidas.' : 'Unidade ou senha incorretos.');
      }
    } else {
      const timestamp = new Date().toISOString();
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'RESIDENT',
        name: formData.name,
        password: formData.password,
        unit: formData.unit,
        phone: formData.phone
      };

      if (state.users.some(u => u.unit === formData.unit)) {
        alert('Esta unidade já possui um cadastro ativo.');
        return;
      }

      dbService.saveUser(newUser);
      dbService.saveResident({ 
        id: newUser.id, 
        name: newUser.name, 
        unit: newUser.unit!, 
        phone: newUser.phone!,
        createdAt: timestamp
      });
      onSuccess(newUser);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="p-8">
          <button onClick={onBack} className="text-slate-400 hover:text-slate-600 mb-6 transition-colors flex items-center gap-2 group">
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> Voltar
          </button>
          
          <div className="text-center mb-8">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${mode === 'STAFF' ? 'bg-indigo-600' : 'bg-blue-600'} text-white shadow-lg`}>
              <i className={`fas ${mode === 'STAFF' ? 'fa-user-shield' : 'fa-house-user'} text-2xl`}></i>
            </div>
            <h2 className="text-2xl font-bold text-slate-800">
              {isLogin ? (mode === 'STAFF' ? 'Acesso Portaria' : 'Portal do Morador') : 'Criar Conta'}
            </h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label>
                <input required className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
            )}

            {mode === 'STAFF' ? (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Usuário / Email</label>
                <input required className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-indigo-500" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Unidade</label>
                  <input required className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500" value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
                  <input required={!isLogin} className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Senha</label>
              <input required type="password" placeholder="••••••••" className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
            </div>

            {isLogin && (
              <label className="flex items-center gap-2 cursor-pointer py-1">
                <input type="checkbox" className="w-4 h-4 rounded text-blue-600" checked={rememberMe} onChange={e => setRememberMe(e.target.checked)} />
                <span className="text-sm text-slate-600">Lembrar meus dados</span>
              </label>
            )}

            <button type="submit" className={`w-full py-4 rounded-xl text-white font-bold shadow-lg transition-transform active:scale-95 ${mode === 'STAFF' ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-blue-600 hover:bg-blue-700'}`}>
              {isLogin ? 'Entrar' : 'Cadastrar'}
            </button>
          </form>

          {mode === 'RESIDENT' && (
            <button onClick={() => setIsLogin(!isLogin)} className="w-full mt-6 text-sm text-slate-500 hover:text-blue-600 font-medium">
              {isLogin ? 'Não tem conta? Cadastre-se' : 'Já tem conta? Entre aqui'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
