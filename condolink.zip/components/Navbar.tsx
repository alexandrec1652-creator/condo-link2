
import React, { useState, useEffect } from 'react';
import { ViewMode, Notification } from '../types';

interface NavbarProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  notifications: Notification[];
  activeUnit: string;
  onMarkRead: (id: string) => void;
  onLogout: () => void;
  userName?: string;
}

const Navbar: React.FC<NavbarProps> = ({ viewMode, notifications, activeUnit, onMarkRead, onLogout, userName }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const unitNotifications = notifications.filter(n => n.unit === activeUnit);
  const unreadCount = unitNotifications.filter(n => !n.read).length;

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <i className="fas fa-boxes-packing text-white text-xl"></i>
          </div>
          <div className="hidden xs:block">
            <span className="font-bold text-lg text-slate-800 tracking-tight block leading-none">CondoLink</span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              {viewMode === 'STAFF' ? 'Portaria' : `Unidade ${activeUnit}`}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          {deferredPrompt && (
            <button 
              onClick={handleInstallClick}
              className="bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 shadow-md animate-bounce"
            >
              <i className="fas fa-download"></i> Instalar App
            </button>
          )}

          {viewMode === 'RESIDENT' && (
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors relative"
              >
                <i className="fas fa-bell text-xl"></i>
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white border border-slate-200 shadow-xl rounded-xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="p-4 border-b bg-slate-50 flex justify-between items-center">
                    <h3 className="font-semibold text-slate-800">Notificações</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {unitNotifications.length > 0 ? (
                      unitNotifications.map(n => (
                        <div 
                          key={n.id} 
                          onClick={() => {
                            onMarkRead(n.id);
                            setShowNotifications(false);
                          }}
                          className={`p-4 border-b hover:bg-slate-50 cursor-pointer transition-colors ${!n.read ? 'bg-blue-50/50' : ''}`}
                        >
                          <p className="text-sm text-slate-700 leading-snug">{n.message}</p>
                          <p className="text-[10px] text-slate-400 mt-2">
                            {new Date(n.timestamp).toLocaleString('pt-BR')}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center text-slate-400 italic text-sm">
                        Nenhuma notificação.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <button 
            onClick={onLogout}
            className="flex items-center gap-2 text-slate-400 hover:text-red-500 transition-colors p-2"
            title="Sair"
          >
            <i className="fas fa-sign-out-alt text-xl"></i>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
