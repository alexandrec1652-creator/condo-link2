
import React, { useState, useEffect } from 'react';
import { Parcel, ParcelStatus, Notice } from '../types';

interface ResidentDashboardProps {
  unit: string;
  parcels: Parcel[];
  notices: Notice[];
  onCollect: (id: string, name: string) => void;
}

const ResidentDashboard: React.FC<ResidentDashboardProps> = ({ unit, parcels, notices, onCollect }) => {
  const [collectorNames, setCollectorNames] = useState<Record<string, string>>({});
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [showToast, setShowToast] = useState<string | null>(null);
  
  const pendingParcels = parcels.filter(p => p.status === ParcelStatus.PENDING);
  const collectedParcels = parcels.filter(p => p.status === ParcelStatus.COLLECTED);

  // Auto-hide toast after 3 seconds
  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const handleUpdateName = (id: string, name: string) => {
    setCollectorNames(prev => ({ ...prev, [id]: name }));
  };

  const confirmReceipt = (parcel: Parcel) => {
    const name = collectorNames[parcel.id] || '';
    if (!name.trim()) {
      alert('Por favor, informe o nome de quem está retirando a encomenda.');
      return;
    }
    
    setProcessingId(parcel.id);
    
    setTimeout(() => {
      onCollect(parcel.id, name);
      setProcessingId(null);
      setShowToast(`Encomenda da ${parcel.carrier || 'Logística'} confirmada com sucesso!`);
      
      setCollectorNames(prev => {
        const next = { ...prev };
        delete next[parcel.id];
        return next;
      });
    }, 600);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 relative">
      {/* Toast de Sucesso */}
      {showToast && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-[60] animate-in slide-in-from-top-4">
          <div className="bg-green-600 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-green-500">
            <i className="fas fa-check-circle text-lg"></i>
            <span className="font-bold text-sm">{showToast}</span>
            <button onClick={() => setShowToast(null)} className="ml-2 hover:text-green-200">
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
      )}

      {/* Seção de Comunicados Oficiais */}
      {notices.length > 0 && (
        <section className="animate-in slide-in-from-top-4 duration-700">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-amber-500 w-1.5 h-6 rounded-full shadow-lg shadow-amber-200"></div>
            <h2 className="text-lg font-bold text-slate-800">Comunicados do Condomínio</h2>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {notices.map((notice, idx) => (
              <div key={notice.id} className={`bg-white border-l-4 border-amber-500 rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${idx === 0 ? 'ring-2 ring-amber-100' : ''}`}>
                <div className="flex gap-4">
                  <div className="bg-amber-100 text-amber-600 w-12 h-12 rounded-full flex items-center justify-center shrink-0">
                    <i className="fas fa-bullhorn text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-800 leading-tight">{notice.title}</h3>
                    <p className="text-sm text-slate-600 mt-1">{notice.content}</p>
                    <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-wider">
                      Postado em {new Date(notice.timestamp).toLocaleDateString('pt-BR')} às {new Date(notice.timestamp).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                    </p>
                  </div>
                </div>
                {idx === 0 && (
                  <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase self-start md:self-center">
                    Novo
                  </span>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Área do Proprietário - Unidade {unit}</h1>
          <p className="text-slate-500 text-sm">Gerencie suas encomendas e confirme retiradas diretamente pelo App.</p>
        </div>
        <div className="bg-white border border-slate-200 px-4 py-2 rounded-lg shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
            <i className="fas fa-house-user"></i>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase leading-none">Minha Unidade</p>
            <p className="text-sm font-bold text-slate-700">{unit}</p>
          </div>
        </div>
      </div>

      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-orange-500 w-1.5 h-6 rounded-full"></div>
          <h2 className="text-lg font-bold text-slate-800">Encomendas Disponíveis ({pendingParcels.length})</h2>
        </div>
        
        {pendingParcels.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingParcels.map(parcel => (
              <div key={parcel.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col group">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-orange-50 p-3 rounded-xl text-orange-600 border border-orange-100 group-hover:scale-110 transition-transform">
                    <i className="fas fa-box-open text-2xl"></i>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Registrado em</p>
                    <p className="text-sm font-bold text-slate-700">
                      {new Date(parcel.receivedAt).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
                
                <div className="mb-6 flex-grow">
                  <h3 className="font-extrabold text-slate-800 text-lg mb-1">{parcel.carrier || 'Encomenda'}</h3>
                  <p className="text-xs text-slate-500 mb-2">Para: <span className="font-medium">{parcel.recipientName}</span></p>
                  <p className="text-sm text-slate-600">
                    Sua encomenda já está na portaria. Ao retirar fisicamente, confirme aqui para arquivarmos o registro.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 focus-within:border-blue-300 transition-colors">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Quem está retirando?</label>
                    <input 
                      type="text"
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      placeholder="Nome completo do portador"
                      value={collectorNames[parcel.id] || ''}
                      onChange={(e) => handleUpdateName(parcel.id, e.target.value)}
                    />
                  </div>
                  
                  <button 
                    onClick={() => confirmReceipt(parcel)}
                    disabled={processingId === parcel.id}
                    className={`w-full font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg ${
                      processingId === parcel.id 
                      ? 'bg-slate-200 text-slate-500 cursor-not-allowed' 
                      : 'bg-blue-600 hover:bg-blue-700 text-white active:scale-95 shadow-blue-100'
                    }`}
                  >
                    {processingId === parcel.id ? (
                      <i className="fas fa-circle-notch fa-spin"></i>
                    ) : (
                      <i className="fas fa-check-double"></i>
                    )}
                    Confirmar Retirada
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-2xl p-12 text-center text-slate-400">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-clipboard-check text-3xl text-slate-200"></i>
            </div>
            <p className="text-sm font-medium">Nenhuma encomenda aguardando retirada para a unidade {unit}.</p>
          </div>
        )}
      </section>

      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-lg font-bold text-slate-800">Meu Histórico de Retiradas</h2>
          <span className="text-xs font-semibold text-slate-500 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-xs">
            {collectedParcels.length} Registros
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Entrada</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Transportadora</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Coletado por</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Data Retirada</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {collectedParcels.length > 0 ? collectedParcels.map(parcel => (
                <tr key={parcel.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-600 font-medium">
                      {new Date(parcel.receivedAt).toLocaleDateString('pt-BR')}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-slate-800">{parcel.carrier || 'Encomenda'}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-[10px]">
                        <i className="fas fa-user"></i>
                      </div>
                      <span className="text-sm text-slate-700 font-medium">
                        {parcel.collectedBy || parcel.recipientName}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-xs text-green-600 font-bold flex items-center gap-1">
                      <i className="fas fa-check text-[10px]"></i>
                      {parcel.collectedAt ? new Date(parcel.collectedAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '-'}
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-6 py-16 text-center text-slate-400 italic text-sm">
                    Você ainda não possui histórico de retiradas registradas no sistema.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default ResidentDashboard;
