
import React, { useState } from 'react';
import { Resident } from '../types';

interface ResidentManagementProps {
  residents: Resident[];
  onAdd: (resident: Omit<Resident, 'id'>) => void;
  onDelete: (id: string) => void;
}

const ResidentManagement: React.FC<ResidentManagementProps> = ({ residents, onAdd, onDelete }) => {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    unit: '',
    phone: '',
    email: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.unit || !formData.phone) return;
    onAdd(formData);
    setFormData({ name: '', unit: '', phone: '', email: '' });
    setShowForm(false);
  };

  // Ordenar: os cadastros mais recentes primeiro
  const sortedResidents = [...residents].sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return dateB - dateA;
  });

  const isRecent = (dateStr?: string) => {
    if (!dateStr) return false;
    const diff = new Date().getTime() - new Date(dateStr).getTime();
    return diff < 1000 * 60 * 10; // Menos de 10 minutos
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Gerenciamento de Moradores</h2>
          <p className="text-xs text-slate-500">Lista atualizada em tempo real conforme novos cadastros ocorrem.</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 shadow-lg shadow-blue-100"
        >
          <i className={`fas ${showForm ? 'fa-times' : 'fa-user-plus'}`}></i>
          {showForm ? 'Cancelar' : 'Novo Morador'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-blue-100 shadow-xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-in slide-in-from-top-2">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label>
            <input 
              required
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Ex: Carlos Oliveira"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Unidade / Apto</label>
            <input 
              required
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Ex: 101-A"
              value={formData.unit}
              onChange={e => setFormData({...formData, unit: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">WhatsApp (com DDD)</label>
            <input 
              required
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Ex: 11999999999"
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value})}
            />
          </div>
          <div className="flex items-end">
            <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold text-sm hover:bg-blue-700 transition-colors">
              Salvar Morador
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">Nome</th>
              <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">Unidade</th>
              <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">WhatsApp</th>
              <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {sortedResidents.length > 0 ? sortedResidents.map(r => (
              <tr key={r.id} className={`hover:bg-slate-50 transition-colors ${isRecent(r.createdAt) ? 'bg-indigo-50/30' : ''}`}>
                <td className="px-6 py-4 text-sm font-medium text-slate-900">
                  <div className="flex items-center gap-2">
                    {r.name}
                    {isRecent(r.createdAt) && (
                      <span className="bg-indigo-100 text-indigo-700 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase animate-pulse">Novo</span>
                    )}
                  </div>
                  {r.createdAt && (
                    <div className="text-[10px] text-slate-400">Cadastrado em {new Date(r.createdAt).toLocaleString('pt-BR')}</div>
                  )}
                </td>
                <td className="px-6 py-4 text-sm text-slate-600 font-bold">{r.unit}</td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  <span className="flex items-center gap-2">
                    <i className="fab fa-whatsapp text-green-500"></i>
                    {r.phone}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => onDelete(r.id)} className="text-slate-300 hover:text-red-500 p-2 transition-colors">
                    <i className="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-slate-400 italic text-sm">
                  Nenhum morador cadastrado no sistema.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResidentManagement;
