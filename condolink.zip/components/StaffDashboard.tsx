
import React, { useState } from 'react';
import { Parcel, ParcelStatus, Resident, Notice } from '../types';
import ResidentManagement from './ResidentManagement';

interface StaffDashboardProps {
  parcels: Parcel[];
  residents: Resident[];
  notices: Notice[];
  onAdd: (data: any) => Promise<void>;
  onCollect: (id: string, name: string) => void;
  onDelete: (id: string) => void;
  onAddResident: (data: any) => void;
  onDeleteResident: (id: string) => void;
  onAddNotice: (data: { title: string, content: string }) => void;
  onDeleteNotice: (id: string) => void;
}

const StaffDashboard: React.FC<StaffDashboardProps> = ({ 
  parcels, residents, notices, onAdd, onCollect, onDelete, onAddResident, onDeleteResident, onAddNotice, onDeleteNotice
}) => {
  const [activeTab, setActiveTab] = useState<'PARCELS' | 'RESIDENTS' | 'NOTICES'>('PARCELS');
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [formData, setFormData] = useState({ recipientName: '', unit: '', carrier: '', description: '' });

  const pendingCount = parcels.filter(p => p.status === ParcelStatus.PENDING).length;

  const filteredParcels = parcels.filter(p => 
    p.unit.includes(search) || 
    p.recipientName.toLowerCase().includes(search.toLowerCase()) ||
    p.carrier.toLowerCase().includes(search.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAdd(formData);
    setFormData({ recipientName: '', unit: '', carrier: '', description: '' });
    setShowForm(false);
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Estatísticas Rápidas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Pendentes</p>
          <p className="text-2xl font-black text-amber-500">{pendingCount}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Moradores</p>
          <p className="text-2xl font-black text-blue-600">{residents.length}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Comunicados</p>
          <p className="text-2xl font-black text-indigo-600">{notices.length}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Total Entregas</p>
          <p className="text-2xl font-black text-slate-800">{parcels.length}</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
          {['PARCELS', 'RESIDENTS', 'NOTICES'].map(tab => (
            <button 
              key={tab} 
              onClick={() => setActiveTab(tab as any)} 
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === tab ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {tab === 'PARCELS' ? 'Encomendas' : tab === 'RESIDENTS' ? 'Moradores' : 'Mural'}
            </button>
          ))}
        </div>
        
        {activeTab === 'PARCELS' && (
          <button 
            onClick={() => setShowForm(!showForm)} 
            className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
          >
            <i className={`fas ${showForm ? 'fa-times' : 'fa-plus'}`}></i>
            {showForm ? 'Fechar' : 'Nova Entrada'}
          </button>
        )}
      </div>

      {activeTab === 'PARCELS' && (
        <div className="space-y-4">
          {showForm && (
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border-2 border-blue-100 shadow-xl grid grid-cols-1 md:grid-cols-4 gap-4 animate-slide-up">
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Morador</label>
                <input 
                  required 
                  list="res-list"
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
                  placeholder="Buscar morador..." 
                  value={formData.recipientName} 
                  onChange={e => {
                    const res = residents.find(r => r.name === e.target.value);
                    setFormData({...formData, recipientName: e.target.value, unit: res ? res.unit : formData.unit});
                  }} 
                />
                <datalist id="res-list">{residents.map(r => <option key={r.id} value={r.name}>{r.unit}</option>)}</datalist>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Unidade</label>
                <input required className="w-full border rounded-xl px-3 py-2 text-sm outline-none bg-slate-50" placeholder="Ex: 101" value={formData.unit} readOnly />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Transportadora</label>
                <input className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Ex: Mercado Livre" value={formData.carrier} onChange={e => setFormData({...formData, carrier: e.target.value})} />
              </div>
              <button type="submit" className="bg-blue-600 text-white rounded-xl font-bold self-end py-2.5 hover:bg-blue-700 shadow-md shadow-blue-100">
                Registrar e Avisar IA
              </button>
            </form>
          )}

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
             <div className="p-4 border-b border-slate-50">
               <div className="relative">
                <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                <input 
                  type="text" 
                  placeholder="Pesquisar registros..." 
                  className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border-transparent rounded-xl text-sm outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all" 
                  value={search} 
                  onChange={e => setSearch(e.target.value)} 
                />
              </div>
             </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase border-b">
                  <tr>
                    <th className="px-6 py-4">Informações</th>
                    <th className="px-6 py-4">Logística</th>
                    <th className="px-6 py-4">Data</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y text-sm">
                  {filteredParcels.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-800">{p.recipientName}</div>
                        <div className="text-[10px] text-blue-600 font-black">UNIDADE {p.unit}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-slate-600 font-medium">{p.carrier || 'Particular'}</span>
                      </td>
                      <td className="px-6 py-4 text-slate-400 text-[11px]">
                        {new Date(p.receivedAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${p.status === ParcelStatus.PENDING ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'}`}>
                          {p.status === ParcelStatus.PENDING ? 'Disponível' : 'Retirado'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {p.status === ParcelStatus.PENDING && (
                            <button onClick={() => {
                              const name = prompt("Confirmar nome de quem retirou:", p.recipientName);
                              if(name) onCollect(p.id, name);
                            }} className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg"><i className="fas fa-check"></i></button>
                          )}
                          <button onClick={() => onDelete(p.id)} className="text-slate-300 hover:text-red-500 p-2 rounded-lg"><i className="fas fa-trash"></i></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'RESIDENTS' && <ResidentManagement residents={residents} onAdd={onAddResident} onDelete={onDeleteResident} />}

      {activeTab === 'NOTICES' && (
        <div className="space-y-6 animate-slide-up">
          <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-xl shadow-indigo-100">
            <h3 className="font-black text-lg mb-4 flex items-center gap-2"><i className="fas fa-bullhorn"></i> Mural Digital</h3>
            <form onSubmit={e => { e.preventDefault(); const t = (e.target as any).title.value; const c = (e.target as any).content.value; onAddNotice({title:t, content:c}); (e.target as any).reset(); }} className="space-y-3">
              <input name="title" required placeholder="Título do aviso..." className="w-full bg-indigo-500/50 border-none placeholder-indigo-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white" />
              <textarea name="content" required placeholder="Escreva o comunicado para os moradores..." className="w-full bg-indigo-500/50 border-none placeholder-indigo-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white" rows={2} />
              <button type="submit" className="bg-white text-indigo-600 px-6 py-2.5 rounded-xl font-bold hover:bg-indigo-50 transition-colors">Publicar Agora</button>
            </form>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notices.map(n => (
              <div key={n.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative group">
                <button onClick={() => onDeleteNotice(n.id)} className="absolute top-4 right-4 text-slate-200 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><i className="fas fa-times"></i></button>
                <h4 className="font-bold text-slate-800 pr-6">{n.title}</h4>
                <p className="text-sm text-slate-500 mt-2">{n.content}</p>
                <div className="flex items-center gap-2 mt-4 text-[10px] font-bold text-slate-400 uppercase">
                  <span>{new Date(n.timestamp).toLocaleDateString()}</span>
                  <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
                  <span className="text-indigo-500">{n.author}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffDashboard;
