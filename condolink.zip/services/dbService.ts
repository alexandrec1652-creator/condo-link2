import { User, Parcel, Resident, Notification, Notice, ParcelStatus } from '../types';

const DB_KEY = 'condolink_v2_db';
const channel = new BroadcastChannel('condolink_sync');

interface DBState {
  users: User[];
  parcels: Parcel[];
  residents: Resident[];
  notifications: Notification[];
  notices: Notice[];
}

const initialState: DBState = {
  users: [],
  parcels: [],
  residents: [],
  notifications: [],
  notices: []
};

export const dbService = {
  getState(): DBState {
    try {
      const data = localStorage.getItem(DB_KEY);
      return data ? JSON.parse(data) : initialState;
    } catch (e) {
      console.error("Erro ao ler banco de dados local:", e);
      return initialState;
    }
  },

  setState(newState: DBState) {
    localStorage.setItem(DB_KEY, JSON.stringify(newState));
    channel.postMessage('SYNC');
    // Forçar atualização na mesma aba também
    window.dispatchEvent(new Event('storage_update'));
  },

  onUpdate(callback: (state: DBState) => void) {
    const handler = () => callback(this.getState());
    channel.addEventListener('message', handler);
    window.addEventListener('storage_update', handler);
    return () => {
      channel.removeEventListener('message', handler);
      window.removeEventListener('storage_update', handler);
    };
  },

  saveUser(user: User) {
    const state = this.getState();
    this.setState({ ...state, users: [...state.users, user] });
  },

  saveParcel(parcel: Parcel) {
    const state = this.getState();
    this.setState({ ...state, parcels: [parcel, ...state.parcels] });
  },

  collectParcel(id: string, collector: string) {
    const state = this.getState();
    const updated = state.parcels.map(p => p.id === id ? {
      ...p, 
      status: ParcelStatus.COLLECTED, 
      collectedAt: new Date().toISOString(), 
      collectedBy: collector
    } : p);
    this.setState({ ...state, parcels: updated });
  },

  deleteParcel(id: string) {
    const state = this.getState();
    this.setState({ ...state, parcels: state.parcels.filter(p => p.id !== id) });
  },

  saveResident(resident: Resident) {
    const state = this.getState();
    // Evitar duplicatas por unidade
    const filtered = state.residents.filter(r => r.unit !== resident.unit);
    this.setState({ ...state, residents: [resident, ...filtered] });
  },

  deleteResident(id: string) {
    const state = this.getState();
    this.setState({ ...state, residents: state.residents.filter(r => r.id !== id) });
  },

  saveNotification(notif: Notification) {
    const state = this.getState();
    this.setState({ ...state, notifications: [notif, ...state.notifications] });
  },

  markNotificationRead(id: string) {
    const state = this.getState();
    this.setState({ ...state, notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n) });
  },

  saveNotice(notice: Notice) {
    const state = this.getState();
    this.setState({ ...state, notices: [notice, ...state.notices] });
  },

  deleteNotice(id: string) {
    const state = this.getState();
    this.setState({ ...state, notices: state.notices.filter(n => n.id !== id) });
  }
};