import { GoogleGenAI } from "@google/genai";
import { Parcel } from "../types";

export const generateNotificationMessage = async (parcel: Parcel): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Gere uma notificação curta e educada.
      Destinatário: ${parcel.recipientName}
      Unidade: ${parcel.unit}
      Transportadora: ${parcel.carrier || 'Logística'}`,
      config: {
        systemInstruction: "Você é o assistente virtual do Edifício Jaú. Crie mensagens curtas para os moradores sobre a chegada de encomendas. Exemplo: 'Olá! Uma encomenda da Amazon chegou para você na portaria. Pode retirar quando quiser.'",
        temperature: 0.7,
      },
    });

    return response.text?.trim() || `Portaria: Sua encomenda da ${parcel.carrier} chegou, Unidade ${parcel.unit}!`;
  } catch (error) {
    console.error("Erro Gemini:", error);
    return `Olá! Sua encomenda da ${parcel.carrier} já está disponível na portaria.`;
  }
};