export const notificationService = {
  async requestPermission() {
    if (!('Notification' in window)) {
      console.warn('Este navegador não suporta notificações desktop');
      return false;
    }

    if (Notification.permission === 'granted') return true;

    const permission = await Notification.requestPermission();
    return permission === 'granted';
  },

  async show(title: string, body: string) {
    if (Notification.permission !== 'granted') return;

    // Use Service Worker registration if available for better mobile support
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      // Fixed: Cast the options object to any to bypass the missing 'vibrate' property 
      // in the standard NotificationOptions type definition while remaining functional at runtime.
      registration.showNotification(title, {
        body,
        icon: 'https://cdn-icons-png.flaticon.com/512/1157/1157000.png',
        badge: 'https://cdn-icons-png.flaticon.com/512/1157/1157000.png',
        vibrate: [200, 100, 200],
        tag: 'condolink-notice',
        renotify: true
      } as any);
    } else {
      new Notification(title, { body });
    }
  }
};